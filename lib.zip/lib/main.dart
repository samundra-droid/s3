import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Removes the debug banner
      title: 'Digital Picture Frame',
      theme: ThemeData(useMaterial3: true, primarySwatch: Colors.blue),
      home: const PictureFrame(),
    );
  }
}

class PictureFrame extends StatefulWidget {
  const PictureFrame({super.key});

  @override
  State<PictureFrame> createState() => _PictureFrameState();
}

class _PictureFrameState extends State<PictureFrame> {
  // List of image URLs from AWS S3 bucket
  final List<String> imageUrls = [
    'https://biswashb.s3.us-east-1.amazonaws.com/vaughan+1.jpg',
    'https://biswashb.s3.us-east-1.amazonaws.com/vaughan+2.jpg',
  ];

  int currentIndex = 0; // Tracks current image index
  bool isPaused = false; // Tracks pause/resume state
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  // Starts the timer for image rotation
  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (!isPaused) {
        setState(() {
          currentIndex = (currentIndex + 1) % imageUrls.length;
        });
      }
    });
  }

  // Toggle pause/resume
  void _togglePause() {
    setState(() {
      isPaused = !isPaused;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Digital Picture Frame'),
      ),
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(10.0),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.blue, width: 10),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Image.network(
            imageUrls[currentIndex],
            fit: BoxFit.cover,
            loadingBuilder: (context, child, progress) {
              if (progress == null) return child;
              return const CircularProgressIndicator();
            },
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _togglePause,
        tooltip: isPaused ? 'Resume' : 'Pause',
        child: Icon(isPaused ? Icons.play_arrow : Icons.pause),
      ),
    );
  }
}
